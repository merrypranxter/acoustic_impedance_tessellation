# acoustic_impedance_tessellation

> Screen-as-tissue ultrasound warp. Sound meets surface, and the surface remembers.

## What This Is

When sound waves hit a boundary between two materials, some reflects and some transmits. The ratio depends on **acoustic impedance** Z = ρc (density × speed of sound). A large impedance mismatch means strong reflection; similar impedances mean clean transmission.

This repo simulates that physics on the screen:
- The screen is a **2D tissue phantom** with varying impedance
- An ultrasound **pulse** propagates through it
- Reflections at boundaries create the **image**
- Speckle, attenuation, and beam spreading add realism

## Physics Model

### 1. Wave Propagation
```
∂²p/∂t² = c²∇²p - α∂p/∂t
```
Pressure wave with speed c and attenuation α.

### 2. Reflection/Transmission
```
R = ((Z₂ - Z₁)/(Z₂ + Z₁))²  // Reflection coefficient
T = 1 - R                      // Transmission coefficient
```

### 3. Tissue Properties
| Tissue | Density (kg/m³) | Speed (m/s) | Impedance (MRayl) |
|--------|----------------|-------------|-------------------|
| Air | 1.2 | 330 | 0.0004 |
| Fat | 920 | 1450 | 1.33 |
| Water | 1000 | 1480 | 1.48 |
| Muscle | 1060 | 1580 | 1.67 |
| Bone | 1900 | 4080 | 7.75 |

## Visual Output

### 1. B-Mode (Brightness Mode)
Standard grayscale ultrasound. The classic "fuzzy" medical image.

### 2. M-Mode (Motion Mode)
One scan line over time. Shows motion of structures.

### 3. Color Doppler
Blood flow direction and velocity mapped to color (red = toward, blue = away).

### 4. Elastography
Tissue stiffness mapped to color. Stiffer = more likely pathological.

### 5. Artifact Showcase
- **Reverberation** — multiple reflections between strong interfaces
- **Shadowing** — bone blocks sound, creating dark regions behind
- **Enhancement** — fluid transmits sound well, brightening behind
- **Refraction** — bending at curved interfaces
- **Speckle** — interference pattern from scattering

## Parameters

- `probe_frequency` — 2-15 MHz (higher = better resolution, less penetration)
- `tissue_preset` — abdomen / cardiac / vascular / musculoskeletal / ocular
- `gain` — overall amplification
- `time_gain_compensation` — boost deeper signals (attenuation compensation)
- `focus_depth` — where the beam is narrowest
- `dynamic_range` — compression curve for displayed intensities

## Shader Architecture

```glsl
// Ultrasound wave simulation
float ultrasound_pulse(vec2 pos, float time) {
    float wave = 0.0;
    
    // Emit from probe (top edge)
    for (int i = 0; i < NUM_ELEMENTS; i++) {
        float delay = element_delay(i, focus_depth);
        float dist = distance(pos, probe_element(i));
        float phase = 2.0 * PI * (frequency * (time - dist/speed - delay));
        wave += sin(phase) * beam_profile(dist, angle);
    }
    
    return wave;
}

// Reflection at impedance boundaries
float reflect(vec2 pos, vec2 grad_impedance) {
    float dZ = length(grad_impedance);
    float Z = impedance(pos);
    return (dZ * dZ) / ((2*Z + dZ) * (2*Z + dZ));
}
```

## Variations

### `acoustic_impedance_tessellation/`
```
├── shaders/
│   ├── core/
│   │   ├── wave_equation.glsl    # 2D wave propagation
│   │   ├── impedance_map.glsl    # tissue property textures
│   │   └── beam_forming.glsl     # phased array simulation
│   ├── modes/
│   │   ├── b_mode.frag           # standard grayscale
│   │   ├── m_mode.frag           # motion over time
│   │   ├── color_doppler.frag    // flow velocity
│   │   └── elastography.frag     // stiffness mapping
│   ├── artifacts/
│   │   ├── reverberation.frag    // multipath echoes
│   │   ├── shadowing.frag        // acoustic shadow
│   │   ├── enhancement.frag      // through-transmission bright
│   │   └── speckle.frag          // scattering interference
│   └── demo/
│       ├── beating_heart.frag    // cardiac cycle
│       ├── fetal_scan.frag       // obstetric
│       └── alien_anatomy.frag    // non-human tissue
└── docs/
    ├── ultrasound_physics.md
    └── tissue_properties.md
```

## References

- Kremkau (2015). *Diagnostic Ultrasound: Principles and Instruments*
- Jensen (1996). *Estimation of Blood Velocities Using Ultrasound*
- Szabo (2004). *Diagnostic Ultrasound Imaging: Inside Out*

## Related

- `cymatics_sacred` — shared wave-interference visualization
- `bioluminescence_orb` — shared "light through tissue" aesthetic

---

*The screen is flesh. The shader is sound. The image is the space between them.*
